<template>
    <div class="goodsList">
        <div class="goodsList-left">
            <div v-for="(v,i) in data" :key="i">{{v.name}}</div>
        </div>
        <div class="goodsList-right">
            <div v-for="(v,i) in data" :key="i">
                <div class="title">{{v.name}}</div>
                <div class="info" v-for="(x,z) in v.foods" :key="z">
                    <div class="content">
                        <img :src="x.image" alt="">
                        <div class="goodsInfo">
                            <h5>{{x.name}}</h5>
                            <p  v-if="x.description!=''">{{x.description}}</p>
                            <p>月售{{x.sellCount}}份&emsp;好评率{{x.rating}}%</p>
                            <p>￥{{x.price}}&emsp;<span v-show="x.oldPrice!=''">￥{{x.oldPrice}}</span></p>
                            <div>
                                <button v-show="x.num==0 ? 'disabled' : ''" @click="Reduction(z)">-</button>
                                &emsp;{{x.num}}&emsp;<button @click="Reduction(z)">+</button>                                
                            </div>
                        </div>
                    </div>
                </div>               
            </div>
        </div>
    </div>
</template>

<script>
import { goodsInfo } from '../api/apis.js';
    export default {
        data(){
            return{
                data:{},
            }
        },
        created(){
            //发送请求商家信息
            goodsInfo().then(res=>{
                // console.log(res.data)
                this.data=res.data.data;
                // console.log(this.data)
            })
        },
        methods:{
            Reduction(){
                console.log(111)
            }
        }
    }
</script>

<style lang="less" scoped>
    .goodsList{
        display: flex;
        justify-content: space-around;
        .goodsList-left{
            width: 70px;
            padding: 0 5px;
            background-color: #f4f5f7;
            border-right: solid 2px #d9dce1;
            div{
                height: 50px;
                font-size: 14px;
                text-align: center;
                border-bottom: solid 1px #ccc;
                display: flex;
                align-items: center
            }
        }
        .goodsList-right{
            flex: 1;
            .title{
                padding: 0 20px;
                background-color: #f4f5f7;
                height: 30px;
                line-height: 30px;
                font-size: 14px;
            }
            .info{
                padding: 20px 20px 0 20px;
                font-size: 12px;
                .content{
                    padding-bottom: 20px;
                    border-bottom: solid 1px #ccc;
                    display: flex;
                    justify-content: flex-start;
                    img{
                        width: 60px;
                        height: 60px;
                        margin-right: 10px;
                    }
                    .goodsInfo{
                        flex: 1;
                        position: relative;
                        p{
                            width: 100%;
                            height: 18px;
                            color: #93989c;
                            overflow: hidden;
                            span{
                                text-decoration: line-through;
                                font-size: 12px;
                                color: #93989c
                            }
                        }
                        p:nth-child(4){
                            color: #ff6600;
                            font-size: 14px;
                        }
                        div{
                            width: 60px;
                            height: 20px;
                            position: absolute;
                            right: 0px;
                            bottom: -5px;
                            button{
                                width: 20px;
                                height: 20px;
                                border-radius: 50%;
                                text-align: center;
                                line-height: 20px;
                                font-size: 16px;
                                color: white;
                                border: none;
                                padding: 0;
                                background-color: #00a0dc;
                            }
                        }
                    }
                }
            }
        }
    }
</style>